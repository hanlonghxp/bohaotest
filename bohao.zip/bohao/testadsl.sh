#!/bin/sh 
java -d64 -server -Dadsl-ip=192.168.33.1 -classpath /home/ubuntu203/project/hanlong/boha/:/home/ubuntu203/project/hanlong/boha/adsl-assembly-1.0.0.jar  yks.crawler.ADSLTest

